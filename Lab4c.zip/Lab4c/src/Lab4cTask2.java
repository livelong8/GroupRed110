//Lab 4c (Task 2)

import java.util.Scanner;

public class Lab4cTask2 {
    public static void main(String[] args) {

        //Create Scanner
        Scanner input = new Scanner(System.in);

        //User Input
        System.out.print("Enter an integer: ");
        int number = input.nextInt();

        //Output
        for (int i = 1; i <= 10; i++) {
            System.out.println(number + " x " + i + " = " + number * i);
        }
    }
}