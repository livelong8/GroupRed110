import java.util.Scanner;

public class GradeAnalyzer {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

    //Create & Initialize Variables
        int sumGrades = 0;
        int highestGrade = Integer.MIN_VALUE;
        int lowestGrade = Integer.MAX_VALUE;
        int totalGrades = 0;

        while (true) {
            System.out.println("Enter grades (1-100), or -1 to finish");
            int grade = input.nextInt();

            //Sentinel Value Input
            if (grade == -1) {
                break;
            }

            //Invalid Input
            if (grade < 0 || grade > 100) {
                System.out.println("Invalid grade entered");
                continue;
            }

            //Valid Input
            totalGrades++;
            sumGrades = sumGrades + grade;

            //Deal with the highest & lowest
            if (grade > highestGrade)
                highestGrade = grade;
            if (grade < lowestGrade)
                lowestGrade = grade;
        }




    }
}